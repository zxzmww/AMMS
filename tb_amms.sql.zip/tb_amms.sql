-- phpMyAdmin SQL Dump
-- version 2.10.2
-- http://www.phpmyadmin.net
-- 
-- 主机: localhost
-- 生成日期: 2015 年 01 月 28 日 10:09
-- 服务器版本: 5.1.41
-- PHP 版本: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- 数据库: `tb_amms`
-- 

-- --------------------------------------------------------

-- 
-- 表的结构 `think_access`
-- 

CREATE TABLE `think_access` (
  `role_id` smallint(6) unsigned NOT NULL,
  `node_id` smallint(6) unsigned NOT NULL,
  `level` tinyint(1) NOT NULL,
  `module` varchar(50) DEFAULT NULL,
  `pid` int(11) NOT NULL,
  KEY `groupId` (`role_id`),
  KEY `nodeId` (`node_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- 导出表中的数据 `think_access`
-- 

INSERT INTO `think_access` VALUES (3, 34, 0, NULL, 0);
INSERT INTO `think_access` VALUES (3, 33, 0, NULL, 0);
INSERT INTO `think_access` VALUES (3, 13, 0, NULL, 0);
INSERT INTO `think_access` VALUES (3, 48, 0, NULL, 0);
INSERT INTO `think_access` VALUES (3, 49, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 18, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 17, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 16, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 14, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 50, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 34, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 33, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 32, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 13, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 48, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 49, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 40, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 39, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 38, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 37, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 12, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 23, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 22, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 21, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 20, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 11, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 35, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 10, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 36, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 9, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 27, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 26, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 25, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 24, 0, NULL, 0);
INSERT INTO `think_access` VALUES (3, 12, 0, NULL, 0);
INSERT INTO `think_access` VALUES (3, 36, 0, NULL, 0);
INSERT INTO `think_access` VALUES (3, 9, 0, NULL, 0);
INSERT INTO `think_access` VALUES (3, 1, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 16, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 14, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 50, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 34, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 33, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 32, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 13, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 48, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 49, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 40, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 39, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 38, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 37, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 12, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 23, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 22, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 21, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 20, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 11, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 35, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 10, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 36, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 9, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 27, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 26, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 25, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 24, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 8, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 46, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 8, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 46, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 31, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 30, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 29, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 31, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 30, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 29, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 7, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 3, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 7, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 3, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 47, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 47, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 28, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 6, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 28, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 6, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 5, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 4, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 5, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 4, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 2, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 1, 0, NULL, 0);
INSERT INTO `think_access` VALUES (6, 48, 0, NULL, 0);
INSERT INTO `think_access` VALUES (6, 12, 0, NULL, 0);
INSERT INTO `think_access` VALUES (6, 36, 0, NULL, 0);
INSERT INTO `think_access` VALUES (6, 9, 0, NULL, 0);
INSERT INTO `think_access` VALUES (6, 1, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 2, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 1, 0, NULL, 0);
INSERT INTO `think_access` VALUES (3, 50, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 17, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 18, 0, NULL, 0);
INSERT INTO `think_access` VALUES (1, 19, 0, NULL, 0);
INSERT INTO `think_access` VALUES (2, 19, 0, NULL, 0);

-- --------------------------------------------------------

-- 
-- 表的结构 `think_corp`
-- 

CREATE TABLE `think_corp` (
  `c_id` int(6) NOT NULL AUTO_INCREMENT,
  `c_name` varchar(50) NOT NULL,
  `c_name_en` varchar(50) NOT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- 导出表中的数据 `think_corp`
-- 

INSERT INTO `think_corp` VALUES (1, '平安', '11');
INSERT INTO `think_corp` VALUES (5, '太保', '');
INSERT INTO `think_corp` VALUES (3, '人寿', '');

-- --------------------------------------------------------

-- 
-- 表的结构 `think_crop_cate`
-- 

CREATE TABLE `think_crop_cate` (
  `id` mediumint(6) NOT NULL AUTO_INCREMENT,
  `pid` mediumint(6) NOT NULL,
  `title` varchar(50) NOT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

-- 
-- 导出表中的数据 `think_crop_cate`
-- 

INSERT INTO `think_crop_cate` VALUES (13, 0, '北京', 0);
INSERT INTO `think_crop_cate` VALUES (16, 0, '安徽', 2);
INSERT INTO `think_crop_cate` VALUES (22, 13, '丰台', 2);
INSERT INTO `think_crop_cate` VALUES (23, 13, '总部', 0);
INSERT INTO `think_crop_cate` VALUES (15, 0, '江苏', 1);
INSERT INTO `think_crop_cate` VALUES (17, 16, '合肥', 1);
INSERT INTO `think_crop_cate` VALUES (18, 16, '芜湖', 2);
INSERT INTO `think_crop_cate` VALUES (19, 15, '南京', 1);
INSERT INTO `think_crop_cate` VALUES (20, 15, '苏州', 2);
INSERT INTO `think_crop_cate` VALUES (21, 13, '西城', 1);
INSERT INTO `think_crop_cate` VALUES (24, 15, '总部', 0);
INSERT INTO `think_crop_cate` VALUES (25, 16, '总部', 0);

-- --------------------------------------------------------

-- 
-- 表的结构 `think_node`
-- 

CREATE TABLE `think_node` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `remark` varchar(255) DEFAULT NULL,
  `sort` smallint(6) unsigned DEFAULT NULL,
  `pid` smallint(6) unsigned NOT NULL,
  `level` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `level` (`level`),
  KEY `pid` (`pid`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=51 ;

-- 
-- 导出表中的数据 `think_node`
-- 

INSERT INTO `think_node` VALUES (1, 'Home', '主应用', 1, NULL, NULL, 0, 1);
INSERT INTO `think_node` VALUES (2, 'CorpRole', '公司组织机构', 1, NULL, NULL, 1, 2);
INSERT INTO `think_node` VALUES (3, 'InsuCorpRole', '保险公司组织机构', 1, NULL, NULL, 1, 2);
INSERT INTO `think_node` VALUES (4, 'Listview', '显示', 1, NULL, NULL, 2, 3);
INSERT INTO `think_node` VALUES (5, 'Addview', '添加', 1, NULL, NULL, 2, 3);
INSERT INTO `think_node` VALUES (6, 'Delete', '删除', 1, NULL, NULL, 2, 3);
INSERT INTO `think_node` VALUES (7, 'Delete', '删除', 1, NULL, NULL, 3, 3);
INSERT INTO `think_node` VALUES (8, 'CorpList', '保险公司列表', 1, NULL, NULL, 1, 2);
INSERT INTO `think_node` VALUES (9, 'Index', '控制台', 1, NULL, 0, 1, 2);
INSERT INTO `think_node` VALUES (10, 'Node', '权限模块', 1, NULL, NULL, 1, 2);
INSERT INTO `think_node` VALUES (11, 'Role', '角色模块', 1, NULL, 0, 1, 2);
INSERT INTO `think_node` VALUES (12, 'Service', '维修记录', 1, NULL, NULL, 1, 2);
INSERT INTO `think_node` VALUES (13, 'Syscfg', '系统配置', 1, NULL, NULL, 1, 2);
INSERT INTO `think_node` VALUES (14, 'User', '用户模块', 1, NULL, NULL, 1, 2);
INSERT INTO `think_node` VALUES (16, 'Listview', '显示', 1, NULL, NULL, 14, 3);
INSERT INTO `think_node` VALUES (17, 'Addview', '添加', 1, NULL, NULL, 14, 3);
INSERT INTO `think_node` VALUES (18, 'Delete', '删除', 1, NULL, NULL, 14, 3);
INSERT INTO `think_node` VALUES (19, 'Editview', '编辑', 1, NULL, NULL, 14, 3);
INSERT INTO `think_node` VALUES (20, 'Delete', '删除', 1, NULL, NULL, 11, 3);
INSERT INTO `think_node` VALUES (21, 'Editview', '更新', 1, NULL, NULL, 11, 3);
INSERT INTO `think_node` VALUES (22, 'Addview', '添加', 1, NULL, NULL, 11, 3);
INSERT INTO `think_node` VALUES (23, 'Listview', '显示', 1, NULL, NULL, 11, 3);
INSERT INTO `think_node` VALUES (24, 'dataInsert', '添加', 1, NULL, NULL, 8, 3);
INSERT INTO `think_node` VALUES (25, 'index', '显示', 1, NULL, NULL, 8, 3);
INSERT INTO `think_node` VALUES (26, 'dataDelete', '删除', 1, NULL, NULL, 8, 3);
INSERT INTO `think_node` VALUES (27, 'dataUpdate', '更新', 1, NULL, NULL, 8, 3);
INSERT INTO `think_node` VALUES (28, 'Editview', '编辑', 1, NULL, NULL, 2, 3);
INSERT INTO `think_node` VALUES (29, 'Addview', '添加', 1, NULL, NULL, 3, 3);
INSERT INTO `think_node` VALUES (30, 'Editview', '更新', 1, NULL, NULL, 3, 3);
INSERT INTO `think_node` VALUES (31, 'Listview', '显示', 1, NULL, NULL, 3, 3);
INSERT INTO `think_node` VALUES (32, 'index', '更新配置', 1, NULL, NULL, 13, 3);
INSERT INTO `think_node` VALUES (33, 'PersonInfo', '个人信息维护', 1, NULL, NULL, 13, 3);
INSERT INTO `think_node` VALUES (34, 'ChangePwd', '个人密码修改', 1, NULL, NULL, 13, 3);
INSERT INTO `think_node` VALUES (35, 'index', '配置', 1, NULL, NULL, 10, 3);
INSERT INTO `think_node` VALUES (36, 'index', '显示', 1, NULL, NULL, 9, 3);
INSERT INTO `think_node` VALUES (37, 'Addview', '添加', 1, NULL, NULL, 12, 3);
INSERT INTO `think_node` VALUES (38, 'Editview', '编辑', 1, NULL, NULL, 12, 3);
INSERT INTO `think_node` VALUES (39, 'Delete', '删除', 1, NULL, NULL, 12, 3);
INSERT INTO `think_node` VALUES (40, 'Listview', '显示', 1, NULL, NULL, 12, 3);
INSERT INTO `think_node` VALUES (50, 'ChangePwd_check', 'Ajax密码', 1, NULL, NULL, 13, 3);
INSERT INTO `think_node` VALUES (49, 'View', '维修详细信息', 1, NULL, NULL, 12, 3);
INSERT INTO `think_node` VALUES (48, 'Listview2Insu', '显示保险公司', 1, NULL, NULL, 12, 3);
INSERT INTO `think_node` VALUES (46, 'AjaxGetCate', '数据接口', 1, NULL, NULL, 3, 3);
INSERT INTO `think_node` VALUES (47, 'AjaxGetCate', '数据接口', 1, NULL, NULL, 2, 3);

-- --------------------------------------------------------

-- 
-- 表的结构 `think_parts`
-- 

CREATE TABLE `think_parts` (
  `p_id` int(11) NOT NULL AUTO_INCREMENT,
  `p_name` varchar(50) NOT NULL,
  `p_pricew` decimal(10,2) NOT NULL,
  `p_pricey` decimal(10,2) NOT NULL,
  `p_pricex` decimal(10,2) NOT NULL,
  `p_sid` int(11) NOT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=41 ;

-- 
-- 导出表中的数据 `think_parts`
-- 

INSERT INTO `think_parts` VALUES (20, '', 0.00, 0.00, 0.00, 9);
INSERT INTO `think_parts` VALUES (19, '', 0.00, 0.00, 0.00, 9);
INSERT INTO `think_parts` VALUES (18, '', 0.00, 0.00, 0.00, 9);
INSERT INTO `think_parts` VALUES (21, '', 0.00, 0.00, 0.00, 9);
INSERT INTO `think_parts` VALUES (40, 'xx', 1000.00, 2000.00, 500.00, 13);
INSERT INTO `think_parts` VALUES (35, 'd', 2.00, 0.00, 0.00, 8);
INSERT INTO `think_parts` VALUES (37, 'bb', 1.00, 2.00, 3.00, 1);

-- --------------------------------------------------------

-- 
-- 表的结构 `think_role`
-- 

CREATE TABLE `think_role` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `pid` smallint(6) DEFAULT NULL,
  `status` tinyint(1) unsigned DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- 
-- 导出表中的数据 `think_role`
-- 

INSERT INTO `think_role` VALUES (1, '管理员', 0, 1, '系统管理');
INSERT INTO `think_role` VALUES (2, '维修公司', NULL, 1, '维修公司');
INSERT INTO `think_role` VALUES (3, '保险公司', NULL, 1, '保险公司');

-- --------------------------------------------------------

-- 
-- 表的结构 `think_role_user`
-- 

CREATE TABLE `think_role_user` (
  `role_id` mediumint(9) unsigned DEFAULT NULL,
  `user_id` char(32) DEFAULT NULL,
  KEY `group_id` (`role_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- 导出表中的数据 `think_role_user`
-- 

INSERT INTO `think_role_user` VALUES (1, '1');
INSERT INTO `think_role_user` VALUES (2, '16');
INSERT INTO `think_role_user` VALUES (3, '17');
INSERT INTO `think_role_user` VALUES (1, '13');
INSERT INTO `think_role_user` VALUES (1, '9');
INSERT INTO `think_role_user` VALUES (3, '17');
INSERT INTO `think_role_user` VALUES (3, '17');

-- --------------------------------------------------------

-- 
-- 表的结构 `think_service`
-- 

CREATE TABLE `think_service` (
  `s_id` int(11) NOT NULL AUTO_INCREMENT,
  `s_corp_1` smallint(6) NOT NULL,
  `s_corp_2` smallint(6) NOT NULL,
  `s_salesman` varchar(20) NOT NULL,
  `s_salesman_tel` varchar(20) NOT NULL,
  `s_time_start` varchar(10) NOT NULL,
  `s_time_end` varchar(10) NOT NULL,
  `s_time_reg` varchar(10) NOT NULL,
  `s_corp_insu` smallint(6) NOT NULL,
  `s_number` varchar(20) NOT NULL,
  `s_corp_insu2` smallint(6) NOT NULL,
  `s_corp_insu3` smallint(6) NOT NULL,
  `s_loseman` varchar(20) NOT NULL,
  `s_loseman_tel` varchar(20) NOT NULL,
  `s_fours` varchar(20) NOT NULL,
  `s_fours_person` varchar(20) NOT NULL,
  `s_fours_tel` varchar(20) NOT NULL,
  `s_fours_address` varchar(50) NOT NULL,
  `s_car_master` varchar(20) NOT NULL,
  `s_car_tel` varchar(20) NOT NULL,
  `s_car_num` varchar(20) NOT NULL,
  `s_car_corp` varchar(20) NOT NULL,
  `s_car_brand` varchar(20) NOT NULL,
  `s_car_model` varchar(20) NOT NULL,
  `s_parts` int(10) NOT NULL,
  `s_parts_price` varchar(10) NOT NULL,
  `s_parts_price2` varchar(10) NOT NULL,
  `s_parts_price3` varchar(10) NOT NULL,
  `s_print_all` decimal(10,2) NOT NULL,
  `s_print2_all` decimal(10,2) NOT NULL,
  `s_bill_flag` tinyint(1) NOT NULL,
  `s_bill_time` varchar(10) NOT NULL,
  `s_bill_complete` tinyint(1) NOT NULL,
  `s_bill_completetime` varchar(10) NOT NULL,
  `s_alert_time` varchar(10) NOT NULL,
  `s_remark` varchar(254) NOT NULL,
  PRIMARY KEY (`s_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

-- 
-- 导出表中的数据 `think_service`
-- 

INSERT INTO `think_service` VALUES (1, 15, 20, '张三', '18876543241', '2015-01-30', '2014-12-31', '2015-01-01', 5, '6', 16, 17, '李四', '18776536222', '北京', '22', '10', '11', '12', '13', '14', '15', '16', '17', 18, '19', '20', '21', 22.00, 23.00, 1, '2014-12-02', 1, '2014-12-04', '26', '27');
INSERT INTO `think_service` VALUES (2, 15, 20, '11', '', '2014-12-02', '2014-12-16', '2014-12-10', 3, '', 16, 17, '', '', '1', '', '', '', '', '', '', '', '', '', 0, '', '', '', 0.00, 0.00, 1, '2014-12-17', 1, '2015-01-18', '', '');
INSERT INTO `think_service` VALUES (3, 13, 22, '11', '222', '2015-01-07', '2014-12-29', '2015-01-10', 3, '2', 16, 17, '22', '22', '1', '', '', '', '', '', '', '', '', '', 0, '', '', '', 0.00, 0.00, 1, '', 1, '2015-03-24', '', '');
INSERT INTO `think_service` VALUES (4, 13, 22, '11', '333', '2015-01-23', '2015-01-13', '2015-01-10', 3, '', 16, 17, '', '', '1', '', '', '', '', '', '', '', '', '', 0, '', '', '', 0.00, 0.00, 1, '', 1, '', '', '');
INSERT INTO `think_service` VALUES (5, 13, 22, '444', '444', '2015-01-14', '2015-01-13', '2015-01-10', 1, '', 13, 22, '', '', '1', '', '', '', '', '', '', '', '', '', 0, '', '', '', 0.00, 0.00, 1, '', 1, '', '', '');
INSERT INTO `think_service` VALUES (6, 13, 22, 'xxx', 'xxxx', '2015-01-22', '2015-01-12', '2015-01-10', 1, '', 13, 22, '', '', '1', '', '', '', '', '', '', '', '', '', 0, '', '', '', 0.00, 0.00, 1, '', 1, '', '', '');
INSERT INTO `think_service` VALUES (7, 13, 22, 'vvv', 'vvv', '2015-01-23', '2015-01-27', '2015-01-10', 1, '', 13, 22, '', '', '1', '', '', '', '', '', '', '', '', '', 0, '', '', '', 0.00, 0.00, 1, '', 1, '', '', '');
INSERT INTO `think_service` VALUES (8, 13, 22, '小张', '123', '2015-01-02', '2015-01-12', '2015-01-23', 1, '', 13, 22, '', '', '1', '', '', '', '', '', '1234', 'AODI', 'AODI', 'A8L', 0, '', '', '', 0.00, 0.00, 1, '2015-06-24', 1, '', '', '');
INSERT INTO `think_service` VALUES (9, 13, 22, 'qq', '', '', '2015-03-24', '2015-02-24', 1, '', 13, 22, '', '', '1', '', '', '', '', '', '', '', '', '', 0, '', '', '', 0.00, 0.00, 1, '', 1, '', '', '');
INSERT INTO `think_service` VALUES (10, 13, 22, '', '', '', '', '2015-01-24', 1, '', 13, 22, '', '', '1', '', '', '', '', '', '', '', '', '', 0, '', '', '', 0.00, 0.00, 1, '', 1, '', '', '');
INSERT INTO `think_service` VALUES (11, 13, 22, '333', '', '', '', '2015-02-24', 1, '', 13, 22, '', '', '1', '', '', '', '', '', '', '', '', '', 0, '', '', '', 0.00, 0.00, 1, '', 1, '', '', '');
INSERT INTO `think_service` VALUES (12, 13, 22, '测试安合', '', '', '', '2015-01-24', 3, '', 16, 17, '', '', '1', '', '', '', '', '', '', '', '', '', 0, '', '', '', 0.00, 0.00, 1, '', 1, '', '', '');
INSERT INTO `think_service` VALUES (13, 15, 20, '小李', '12345678', '2015-01-19', '2015-01-23', '2015-01-25', 5, '0001', 15, 20, '小王', '12345', 'aa', 'bb', 'cc', 'dd', 'a', 'b', 'c', 'd', 'e', 'f', 0, '', '', '', 1000.00, 500.00, 1, '2015-01-25', 0, '2015-01-25', 'xx', 'yy');
INSERT INTO `think_service` VALUES (14, 13, 22, '', '', '2015-01-28', '2015-01-27', '2015-01-20', 5, '', 16, 17, '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', 0.00, 0.00, 1, '', 1, '', '', '');

-- --------------------------------------------------------

-- 
-- 表的结构 `think_session`
-- 

CREATE TABLE `think_session` (
  `session_id` varchar(255) NOT NULL,
  `session_expire` int(11) NOT NULL,
  `session_data` blob,
  UNIQUE KEY `session_id` (`session_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- 导出表中的数据 `think_session`
-- 

INSERT INTO `think_session` VALUES ('sjc3s25ik2pqpo98blb36floq1', 1422441196, 0x61636432343066343862353765633334373739623734636164653535656637307c623a303b);

-- --------------------------------------------------------

-- 
-- 表的结构 `think_user`
-- 

CREATE TABLE `think_user` (
  `u_id` int(11) NOT NULL AUTO_INCREMENT,
  `u_username` varchar(20) NOT NULL,
  `u_password` varchar(32) NOT NULL,
  `u_loginip` varchar(15) NOT NULL,
  `u_logintime` int(10) NOT NULL,
  `u_addtime` int(10) NOT NULL,
  `u_status` tinyint(1) NOT NULL,
  `u_corp_id` int(11) NOT NULL,
  `u_cate_1` int(11) NOT NULL,
  `u_cate_2` int(11) NOT NULL,
  `u_nickname` varchar(20) NOT NULL,
  `u_mobile` varchar(20) NOT NULL,
  `u_email` varchar(50) NOT NULL,
  `u_logincount` int(11) NOT NULL,
  PRIMARY KEY (`u_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

-- 
-- 导出表中的数据 `think_user`
-- 

INSERT INTO `think_user` VALUES (1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '127.0.0.1', 1422098928, 0, 1, 0, 13, 22, '', '', '', 0);
INSERT INTO `think_user` VALUES (13, 'zxzmww', '96e79218965eb72c92a549dd5a330112', '127.0.0.1', 1422103433, 1419828284, 1, 0, 13, 21, '小玩子', '111', 'zxz@qq.com', 0);
INSERT INTO `think_user` VALUES (9, 'superadmin', '21232f297a57a5a743894a0e4a801fc3', '127.0.0.1', 1422437846, 0, 1, 0, 13, 22, '超级管理员', '1234567', 'admin@admin.com', 2);
INSERT INTO `think_user` VALUES (16, 'zhangsan', '96e79218965eb72c92a549dd5a330112', '127.0.0.1', 1422431929, 1422067184, 1, 0, 15, 20, '', '', '', 1);
INSERT INTO `think_user` VALUES (17, 'lisi', 'e3ceb5881a0a1fdaad01296d7554868d', '127.0.0.1', 1422434906, 1422104557, 1, 5, 16, 17, '李四', '5553', 'lis@qq.com', 2);
